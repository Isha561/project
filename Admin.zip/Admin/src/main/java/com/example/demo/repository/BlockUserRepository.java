package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.BlockUser;
import com.example.demo.model.User;

@Repository
public interface BlockUserRepository extends CrudRepository<BlockUser, String> {

	BlockUser findByUsername(String username);

	

}