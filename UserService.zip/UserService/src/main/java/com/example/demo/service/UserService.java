package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.model.UserCompletedTraining;
import com.example.demo.model.UserCurrentTraining;
import com.example.demo.model.UserDetails;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserCompletedRepository;
import com.example.demo.repository.UserCurrentRepository;
import com.example.demo.repository.UserDetailsRepository;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserCompletedRepository usercompletedRepository;
	@Autowired
	private UserCurrentRepository usercurrentRepository;
	@Autowired
	private UserDetailsRepository userdetailsRepository;
	
	public void saveRole(Role r) {
		roleRepository.save(r);
		
	}
	public void saveUser(User u) {
		
		int id=3;
		Role r=roleRepository.findById(id);
		u.setRole(r);
		userRepository.save(u);
		
	}
	
	public User logUser(String username) {
		return userRepository.findByUsername(username);
	}
	
	public void saveUserDetails(UserDetails u) {
		userdetailsRepository.save(u);
		User ud = new User();
		ud.setUsername(u.getUsername());
		ud.setPassword(u.getPassword());
		int id=3;
		Role r = roleRepository.findById(id);
		ud.setRole(r);
		userRepository.save(ud);
		
	}
	public List<UserCompletedTraining> searchCompleted(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return usercompletedRepository.findByUsername(u);
		
	}
	public List<UserCurrentTraining> searchCurrent(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return usercurrentRepository.findByUsername(u);
		
	}
	
	

}
