
export class Mentor {
    
    username : String;
   firstname : String;
   lastname : String;
   contactnumber : any;
   experience : number;
   facilities : String;
}