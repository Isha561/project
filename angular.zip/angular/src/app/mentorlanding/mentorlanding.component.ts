import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorlanding',
  templateUrl: './mentorlanding.component.html',
  styleUrls: ['./mentorlanding.component.css']
})
export class MentorlandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
