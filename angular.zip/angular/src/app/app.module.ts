import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchdetailsComponent } from './searchdetails/searchdetails.component';
import { LoginComponent } from './login/login.component';
import { MentorsignComponent } from './mentorsign/mentorsign.component';
import { UsersignComponent } from './usersign/usersign.component';
import { AdminComponent } from './admin/admin.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { AdminblockComponent } from './adminblock/adminblock.component';
import { HttpClientModule } from '@angular/common/http';
import { FilterPipe } from './filter.pipe';
import { FormsModule}   from '@angular/forms';
import { ReactiveFormsModule} from '@angular/forms'
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { UserloginComponent } from './userlogin/userlogin.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';
import { Searchdetails2Component } from './searchdetails2/searchdetails2.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { PayslipComponent } from './payslip/payslip.component';
import { MentorlandingComponent } from './mentorlanding/mentorlanding.component';
import { AngularWaitBarrier } from 'blocking-proxy/built/lib/angular_wait_barrier';
import { from } from 'rxjs';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

// import { AlertModule } from 'ngx-bootstrap';
@NgModule({
  declarations: [
    AppComponent,
    SearchdetailsComponent,
    LoginComponent,
    MentorsignComponent,
    UsersignComponent,
    AdminComponent,
    MentorProfileComponent,
    AdminblockComponent,
    FilterPipe,
    UserloginComponent,
    MentorloginComponent,
    Searchdetails2Component,
    FrontpageComponent,
    PayslipComponent,
    MentorlandingComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    NgMultiSelectDropDownModule.forRoot()

    // AlertModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
