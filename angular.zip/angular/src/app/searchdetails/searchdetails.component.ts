import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { UserServiceService } from '../userservice.service';

@Component({
  selector: 'app-searchdetails',
  templateUrl: './searchdetails.component.html',
  styleUrls: ['./searchdetails.component.css']
})
export class SearchdetailsComponent implements OnInit {
  public show:boolean = true;
  public current:boolean = false;
  public completed:boolean = false;
  public body:boolean = true;
  public bar:boolean = false;
  private trainers=[];
  private compl=[];
  private curr=[];
  public searchText;
  username: string;
  constructor(private service:UserServiceService,private router:ActivatedRoute) { }

  ngOnInit() {
     this.service.getmentorlist().subscribe(data =>{  this.trainers =data as string[]; });
    this.username=this.router.snapshot.paramMap.get('username')
  }
  // showSearch() {
  //   this.completed=false;
  //   this.current=false;
  //   this.bar=false;
  //   this.service.findtechnology(this.searchText).subscribe(data => this.trainers= data as string[]);
  // }
  search() {
    this.body=true;
    this.completed=false;
    this.current=false;
    this.bar=false;
    this.show=true;
    
  }
  showCurrent() {
    this.body=false;
    this.current=true;
    this.completed=false;
    this.bar=false;
    this.show=false;
    this.service. getUserCurrentList('').subscribe(value =>this.curr=value as string[]);

  }
  showCompleted() {
    this.body=false;
    this.current=false;
    this.completed=true;
    this.bar=false;
    this.service.getUserCompletedList('').subscribe(value =>this.compl=value as string[]);

  }
  showBar() {
    this.bar=true;
    this.show=false;
    this.current=false;
    this.completed=false;
    this.show=false;
  }
}
