import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchdetailsComponent }   from './searchdetails/searchdetails.component';
import { UsersignComponent }   from './usersign/usersign.component';
import { MentorsignComponent }   from './mentorsign/mentorsign.component';
import { AdminblockComponent } from './adminblock/adminblock.component';
import { LoginComponent } from './login/login.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { AdminComponent } from './admin/admin.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';
import { Searchdetails2Component } from './searchdetails2/searchdetails2.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { PayslipComponent } from './payslip/payslip.component';
import { MentorlandingComponent } from './mentorlanding/mentorlanding.component';

const routes: Routes = [
  {path:'', component: SearchdetailsComponent},
  {path:'usersign', component: UsersignComponent},
  {path:'adminblock', component: AdminblockComponent},
  {path:'mentorsign', component: MentorsignComponent},
  {path:'login', component: LoginComponent},
  {path:'userlogin', component:LoginComponent},
  {path:'mentorlogin', component: LoginComponent},
  {path:'mentorprofile',component: MentorProfileComponent},
  {path:'admin',component:AdminComponent},
  {path:'searchdetails2',component:Searchdetails2Component},
  {path:'frontpage',component:FrontpageComponent},
  {path:'payslip',component:PayslipComponent},
  {path:'mentorlanding',component:MentorlandingComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
