import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
//import { User } from './User';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private baseUrl = 'http://localhost:8080/api';  

  constructor(private http: HttpClient) { }

  getUser(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/userservice/loginuser/${username}`);
  }

  // createEmployee(employee: Object): Observable<Object> {
  //   return this.http.post('http://localhost:8086/states', employee);
  // }

  saveuser(usersign : Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/userservice/saveuser`, usersign);
  }
  saveuserdetails(usersign : Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/userservice/saveUserdetails`, usersign);
  }

  getTrainingList(){
    return this.http.get(`${this.baseUrl}/mentor/findmentorlist`);
  }

  getUserCompletedList(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/userservice/findcompleted/${username}`);
  }

  getUserCurrentList(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/userservice/findcurrent/${username}`);
  }


  proposeTrain(id : number,tech : String,username : String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/mentor/proposeTraining/${id}/${tech}/${username}`);
  }

  getUserSearchList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/finduser`);
  }

  getmentorlist(): Observable<any> {
    return this.http.get(`${this.baseUrl}/courseservice/findmentorlist`);
  }


  blockUserService(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/blockuser/${username}`);
  }

  getBlockUserList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/blockuserlist`);
  }

  unblockUserService(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/unblockuser/${username}`);
  }


}
