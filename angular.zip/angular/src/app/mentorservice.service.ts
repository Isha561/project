import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MentorserviceService {

  private baseUrl = 'http://localhost:8080/api';  

  constructor(private http: HttpClient) { }

  createMentor(mentor : Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/mentor/save`, mentor);
  }

  getAdminTechnologyList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/findtechnology`);
  }

  saveTechnology(mentor : String,id : String): Observable<Object> {
    return this.http.post(`${this.baseUrl}/mentor/savetechnology/${mentor}/${id}`, mentor);
  }


  getMentorCompletedList(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/mentor/findcompleted/${username}`);
  }

  getMentorCurrentList(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/mentor/findcurrent/${username}`);
  }


  // getAdminTechnologyList(username : String): Observable<any> {
  //   return this.http.get(`http://localhost:8088//findcurrent/${username}`);
  // }

  
}
