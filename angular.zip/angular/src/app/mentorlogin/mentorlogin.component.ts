import { Component, OnInit } from '@angular/core';
import { User } from '../user'
import { FormGroup,FormControl, Validators} from '@angular/forms'
import {Router} from '@angular/router';

@Component({
  selector: 'app-mentorlogin',
  templateUrl: './mentorlogin.component.html',
  styleUrls: ['./mentorlogin.component.css']
})
export class MentorloginComponent implements OnInit {

  userList: User[]=[];

  form: FormGroup;
  submitted=false;
  validate(form){
    console.log(this.form.value);
    this.router.navigateByUrl('/mentorlanding');

  }
  constructor(private router: Router) {}

  ngOnInit() {
    this.form = new FormGroup({
      name: new FormControl('',[Validators.required,Validators.email]),
      password: new FormControl('',[Validators.required,Validators.pattern("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})")])
    })
  }

}
