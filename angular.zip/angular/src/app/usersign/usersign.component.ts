import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators} from '@angular/forms'
import { confirmValidator } from '../validators';
import {Router} from '@angular/router';
import { Usersign } from '../usersign';
import { UserServiceService } from '../userservice.service';
@Component({
  selector: 'app-usersign',
  templateUrl: './usersign.component.html',
  styleUrls: ['./usersign.component.css']
})
export class UsersignComponent implements OnInit {


  form: FormGroup;
  username : String;
  usign : Usersign = new Usersign();
  save() {
    this.username = this.usign.username;
    // this.usersignserv.saveuser(this.usign)
    //   .subscribe(data => console.log(data), error => console.log(error));
    console.log(this.usign.password);
      this.usersignserv.saveuserdetails(this.usign)
      .subscribe(data => console.log(data), error => console.log(error));
    this.usign = new Usersign();
  }
  validate(){

    // console.log(this.form.value);
    // this.router.navigateByUrl('/userlogin');
    this.save();
  }
  constructor(private router: Router,private usersignserv:UserServiceService) {}
  ngOnInit() {
    this.form = new FormGroup({
      name: new FormControl('',[Validators.required]),
      email: new FormControl('',[Validators.required,Validators.email]),
      linkedurl: new FormControl('',[Validators.required,Validators.pattern("http(s)?:\/\/([w]{3}\.)?linkedin\.com\/in\/([a-zA-Z0-9-]{5,30})\/?")]),

      password: new FormControl('',[Validators.required,Validators.pattern("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})")]),
      confirm: new FormControl('',[Validators.required,confirmValidator])

    })
    // this.form.controls.password.valueChanges
    // .subscribe(
    //   x => this.form.controls.confirm.updateValueAndValidity()
    // )

  }
}
