import { Role } from './Role';

export class User {
    
    username : string;
    password : string;
    role : Role;
}