import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminblock',
  templateUrl: './adminblock.component.html',
  styleUrls: ['./adminblock.component.css']
})
export class AdminblockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
