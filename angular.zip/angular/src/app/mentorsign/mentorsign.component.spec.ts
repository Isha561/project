import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorsignComponent } from './mentorsign.component';

describe('MentorsignComponent', () => {
  let component: MentorsignComponent;
  let fixture: ComponentFixture<MentorsignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorsignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorsignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
