import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators} from '@angular/forms'
import { mentorsign } from '../mentorsign';
import { confirmValidator, time } from '../validators';
import {Router} from '@angular/router';
import { MentorserviceService } from '../mentorservice.service';
import { Mentor } from '../mentor';
@Component({
  selector: 'app-mentorsign',
  templateUrl: './mentorsign.component.html',
  styleUrls: ['./mentorsign.component.css']
})
export class MentorsignComponent implements OnInit {

  userList: mentorsign[]=[];

  data: FormGroup;

  mentordetails : boolean;
   mentortech : boolean;
   mentortime : boolean;
   register : boolean;
  formdata;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  technology = [];
  musername : String;
  // usr:User=new User();

   mntr : Mentor = new Mentor();
  submitted = false;

  constructor(private router: Router,private mentorService:  MentorserviceService) {}
  ngOnInit() {

    this.mentordetails = true;

      
      this.formdata = new FormGroup({
         uname: new FormControl("", Validators.compose([
            Validators.required,
            Validators.minLength(3)
         ])),
           fname: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         lname: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         cnum: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         exp: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         facilities: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         cpasswd: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         
         passwd: new FormControl("", this.passwordvalidation)
      })
  
    

  }

  passwordvalidation(formcontrol) {
    if (formcontrol.value.length < 5) {
       return {"passwd" : true};
    }

    
 }

 save() {
    this.musername = this.mntr.username;
    this.mentorService.createMentor(this.mntr)
      .subscribe(data => console.log(data), error => console.log(error));
    this.mntr = new Mentor();
  }
  validate(){
    //  console.log(this.data.value);
    // this.router.navigateByUrl('/mentorlogin');
    
    this.submitted = true;
    this.save();


     this.mentorService.getAdminTechnologyList().subscribe(data =>{  
                this.dropdownList = data as string[];  
             })

        
 
       this.dropdownSettings= {
          singleSelection: false,
           idField: 'id',
           textField: 'technology',
           selectAllText: 'Select All',
           unSelectAllText: 'UnSelect All',
           // itemsShowLimit: 3,
           allowSearchFilter: true
         };

         this.mentortech = true;
         this.mentordetails=false;


 }

 onItemSelect(item: any) {
    this.technology.push(item);
    console.log(item);
  }
  onSelectAll(items: any) {
     this.technology = items;
    console.log(items);
  }


  addTech(){
     for(let i of this.technology)
     {
       this.mentorService.saveTechnology(this.musername,i.technology)
       .subscribe(data => console.log(data), error => console.log(error));
     }

     this.register = true;
     this.mentortech =false;
     this.mentordetails=false;

  }
}


