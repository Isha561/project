export class Usersign {
    username : string;
    contactnumber:number;
    firstname : String;
     lastname : String;
    password : string;
}
