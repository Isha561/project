import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Searchdetails2Component } from './searchdetails2.component';

describe('Searchdetails2Component', () => {
  let component: Searchdetails2Component;
  let fixture: ComponentFixture<Searchdetails2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Searchdetails2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Searchdetails2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
