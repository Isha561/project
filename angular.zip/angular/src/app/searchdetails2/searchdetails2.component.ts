import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-searchdetails2',
  templateUrl: './searchdetails2.component.html',
  styleUrls: ['./searchdetails2.component.css']
})
export class Searchdetails2Component implements OnInit {
  
  constructor (private httpService: HttpClient) { }
  arrdata: string [];
  ngOnInit () {
    this.httpService.get('./assets/data.json').subscribe(
      data => {
        this.arrdata = data as string [];	 // FILL THE ARRAY WITH DATA.
         console.log(this.arrdata[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }
  search : boolean=true;
  completedcontent : boolean=false;
  currentcontent : boolean=false;
  fullcontent : boolean=true;
  proposal: boolean=false;
  searchtraining(){
    this.search=true;
    this.completedcontent=false;
    this.currentcontent=false
  }
  complete(){
    this.search=false;
    this.completedcontent=true;
    this.currentcontent=false;
  }
  current(){
    this.search=false;
    this.completedcontent=false;
    this.currentcontent=true;
  }
  searchbutton(){
    this.fullcontent=false;
    this.completedcontent=false;
    this.currentcontent=false;
  }
  

  // show(){
  //   this.proposal=true;
  //   this.search=false;
  //   this.completedcontent=false;
  //   this.currentcontent=false;
  // }
}
