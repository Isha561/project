export interface mentorsign{
    fname:string;
    lname:string;
    email:string;
    linkedurl:string;
    exp:number;
    start:number;
    end:number;
    password:string;
    confirm:string;
}