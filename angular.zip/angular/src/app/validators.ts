import { AbstractControl } from '@angular/forms';

export function confirmValidator(control: AbstractControl){
    if (control && (control.value !== null || control.value !== undefined)) {
        const cnfpassValue = control.value;

        const passControl = control.root.get('password'); // magic is this
        if (passControl) {
            const passValue = passControl.value;
            if (passValue !== cnfpassValue || passValue === '') {
                return {
                    isError: true
                };
            }
        }
    }

    return null;
}
export function time(control: AbstractControl){
    if (control && (control.value !== null || control.value !== undefined)) {
        const end = control.value;

        const passControl = control.root.get('start'); // magic is this
        if (passControl) {
            const passValue = passControl.value;
            if (passValue >= end) {
                return {
                    isError: true
                };
            }
        }
    }

    return null;
}