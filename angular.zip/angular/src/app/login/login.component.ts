import { Component, OnInit } from '@angular/core';
import { User } from '../user'
import { FormGroup,FormControl, Validators} from '@angular/forms'
import {Router} from '@angular/router';
import { UserServiceService } from '../userservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  usr:User=new User();
username:string;
password:string;

  form: FormGroup;
  submitted=false;
  
  validate(){
    console.log(this.form.value);
    // this.router.navigateByUrl('/admin');
    this.userService.getUser(this.username).subscribe(value =>{  
      this.usr = value})  

      if(this.usr.password == this.password)
      {

         
         if(this.usr.role.id == 3)
         {
            this.router.navigate(['searchdetails2',{ id: this.username}])
         }
         if(this.usr.role.id == 2)
         {
            this.router.navigate(['mentorlanding',{ id: this.username}])
         }
         if(this.usr.role.id == 1)
         {
            this.router.navigate(['adminblock'])
         }

         
      }

}
  
  constructor(private router: Router,private userService: UserServiceService) {}

  ngOnInit() {
    this.form = new FormGroup({
      uname: new FormControl('',[Validators.required,Validators.email]),
      password: new FormControl('',[Validators.required,Validators.pattern("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})")])
    })
  }

}
